package com.keenplayer.main;

import java.io.File;
import java.io.FileOutputStream;

import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;

public class AddWaterMark {

	public static void main(String[] args)throws Exception {
		
		if(args.length==3)
		{
			if(new File(args[0]).exists()) {
				if(new File(new File(args[1]).getParent()).isDirectory()) {
					if(new File(args[2]).exists()) {
						
						
						PdfReader reader = new PdfReader(args[0]);
						PdfStamper pdfStamper = new PdfStamper(reader,
						    new FileOutputStream(args[1]));
						Image image = Image.getInstance(args[2]);

						for(int i=1; i<= reader.getNumberOfPages(); i++){
						    PdfContentByte content = pdfStamper.getUnderContent(i);
						    image.setAbsolutePosition(150f, 330f);
						    content.addImage(image);
						}

						pdfStamper.close();

					}	
					else
					{
						System.out.println("Enter Output File");
					}
				}else
				{
					System.out.println("Enter Watermark File");
				}
			}
			else
			{
				System.out.println("Enter Source PDF File");
			}
		}
		else
		{
			System.out.println("Please enter all the 3 Paramter File");
		}
	
		
		
	}

}
